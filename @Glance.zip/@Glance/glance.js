
$(document).ready(function(){
    $('#toolbar2').hide();
    $('#toolbar1').show();

    $("#next-toolbar").click(function(){
        $("#toolbar1").hide();
        $('#toolbar2').show();
    });

    $("#prev-toolbar").click(function(){
        $("#toolbar2").hide();
        $('#toolbar1').show();
    });
});

